package com.example.airesumeanalyzer;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class JobFragment extends Fragment {

    private RecyclerView jobsRecyclerView;
    private JobAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_job, container, false);

        swipeRefreshLayout = view.findViewById(R.id.swipeRefresh);
        jobsRecyclerView = view.findViewById(R.id.jobsRecyclerView);
        jobsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new JobAdapter(getContext(), JobRepository.jobList);
        jobsRecyclerView.setAdapter(adapter);

        swipeRefreshLayout.setOnRefreshListener(() -> {
            refreshJobs();
        });

        return view;
    }

    private void refreshJobs() {
        // Simulate real-time fetching
        new Handler().postDelayed(() -> {
            if (JobRepository.jobList.isEmpty()) {
                Toast.makeText(getContext(), "Analyze a resume first to get recommendations", Toast.LENGTH_SHORT).show();
            } else {
                // In a real app, this would re-trigger an API call
                Toast.makeText(getContext(), "Jobs refreshed from latest sources", Toast.LENGTH_SHORT).show();
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
            }
            swipeRefreshLayout.setRefreshing(false);
        }, 1500);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }
}