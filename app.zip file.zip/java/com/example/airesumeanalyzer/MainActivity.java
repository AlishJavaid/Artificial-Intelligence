package com.example.airesumeanalyzer;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    Button btnUpload, btnAnalyze;

    TextView tvFileName, tvResult;

    Uri fileUri;

    String extractedText = "";

    FirebaseFirestore firestore;

    ArrayList<String> detectedSkills =
            new ArrayList<>();

    ArrayList<JobModel> detectedJobs =
            new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUpload = findViewById(R.id.btnUpload);
        btnAnalyze = findViewById(R.id.btnAnalyze);

        tvFileName = findViewById(R.id.tvFileName);
        tvResult = findViewById(R.id.tvResult);

        firestore = FirebaseFirestore.getInstance();

        btnUpload.setOnClickListener(v -> openFilePicker());

        btnAnalyze.setOnClickListener(v -> analyzeResume());
    }

    // FILE PICKER

    ActivityResultLauncher<String[]> filePicker =
            registerForActivityResult(
                    new ActivityResultContracts.OpenDocument(),

                    uri -> {

                        if (uri != null) {

                            fileUri = uri;

                            tvFileName.setText(
                                    "Resume Uploaded Successfully"
                            );

                            extractImageText(uri);
                        }
                    });

    private void openFilePicker() {

        filePicker.launch(new String[]{
                "image/*",
                "application/pdf"
        });
    }

    // OCR TEXT EXTRACTION

    private void extractImageText(Uri uri) {

        try {

            Bitmap bitmap;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {

                bitmap = ImageDecoder.decodeBitmap(
                        ImageDecoder.createSource(
                                getContentResolver(),
                                uri
                        )
                );

            } else {

                bitmap = MediaStore.Images.Media.getBitmap(
                        getContentResolver(),
                        uri
                );
            }

            InputImage image =
                    InputImage.fromBitmap(bitmap, 0);

            TextRecognition.getClient(
                            TextRecognizerOptions.DEFAULT_OPTIONS
                    ).process(image)

                    .addOnSuccessListener(text -> {

                        extractedText =
                                text.getText().toLowerCase();

                        tvFileName.setText(
                                "Resume Text Extracted"
                        );
                    });

        } catch (Exception e) {

            tvResult.setText(e.getMessage());
        }
    }

    // MAIN AI ANALYSIS

    private void analyzeResume() {

        if (extractedText.isEmpty()) {

            tvResult.setText(
                    "Please upload valid CV"
            );

            return;
        }

        detectedSkills.clear();
        detectedJobs.clear();

        int score = 40; // Base score

        // =====================
        // DYNAMIC SKILL ENGINE (WHOLE WORD MATCHING)
        // =====================

        String[] allSkills = {
                "java", "android", "kotlin", "python", "firebase", "html", "css", "javascript", "react", "node", "sql", "php", "c++", "machine learning", "data science", "figma", "photoshop", "illustrator", "marketing", "management", "teaching", "medical", "nursing", "communication", "leadership", "teamwork", "problem solving", "accounting", "excel", "finance", "sales", "seo", "content writing", "graphic design"
        };

        for (String skill : allSkills) {
            // Use regex word boundaries to avoid matching "java" in "javascript"
            Pattern pattern = Pattern.compile("\\b" + Pattern.quote(skill) + "\\b");
            if (pattern.matcher(extractedText).find()) {
                detectedSkills.add(skill);
                score += 4;
            }
        }

        // =====================
        // DYNAMIC JOB MATCHING
        // =====================

        // Format: company, role, salary, primarySkills (at least one required), secondarySkills (optional score booster), source
        addJobIfMatch("Google", "Android Developer", "12 LPA", 
                new String[]{"android", "kotlin"}, 
                new String[]{"java", "firebase", "problem solving"}, "Google Career");

        addJobIfMatch("Microsoft", "Java Developer", "14 LPA", 
                new String[]{"java", "sql"}, 
                new String[]{"c++", "problem solving", "leadership"}, "LinkedIn");

        addJobIfMatch("OpenAI", "AI Engineer", "20 LPA", 
                new String[]{"python", "machine learning", "data science"}, 
                new String[]{"sql", "c++", "problem solving"}, "Google Career");

        addJobIfMatch("Meta", "Digital Marketer", "9 LPA", 
                new String[]{"marketing", "seo"}, 
                new String[]{"content writing", "communication", "management"}, "LinkedIn");

        addJobIfMatch("Adobe", "UI/UX Designer", "10 LPA", 
                new String[]{"figma", "graphic design"}, 
                new String[]{"photoshop", "illustrator", "teamwork"}, "LinkedIn");

        addJobIfMatch("City Hospital", "Medical Professional", "8 LPA", 
                new String[]{"medical", "nursing"}, 
                new String[]{"communication", "teamwork"}, "Indeed");

        addJobIfMatch("Beacon School", "Educator", "5 LPA", 
                new String[]{"teaching"}, 
                new String[]{"management", "communication", "leadership"}, "Indeed");

        addJobIfMatch("Amazon", "Web Developer", "11 LPA", 
                new String[]{"javascript", "react", "node"}, 
                new String[]{"html", "css", "sql", "firebase"}, "Amazon Jobs");

        // IF NOTHING DETECTED

        if (detectedSkills.isEmpty()) {
            detectedSkills.add("Communication");
            detectedSkills.add("Basic Computer Skills");
        }

        if (detectedJobs.isEmpty()) {
            detectedJobs.add(
                    new JobModel(
                            "LinkedIn",
                            "General Professional",
                            "5 LPA",
                            "70%",
                            "LinkedIn"
                    )
            );
        }

        // BUILD RESULT

        StringBuilder skillsText =
                new StringBuilder();

        for (String skill : detectedSkills) {
            skillsText.append("• ")
                    .append(skill.substring(0, 1).toUpperCase() + skill.substring(1))
                    .append("\n");
        }

        StringBuilder jobsText =
                new StringBuilder();

        for (JobModel job : detectedJobs) {
            jobsText.append("• ")
                    .append(job.getRole())
                    .append(" at ")
                    .append(job.getCompany())
                    .append(" (")
                    .append(job.getMatch())
                    .append(")\n");
        }

        if (score > 100) score = 100;

        String finalResult =
                "📊 ATS Resume Score: " + score + "/100\n\n"
                        + "✅ Skills Detected:\n" + skillsText + "\n"
                        + "💼 Recommended Jobs:\n" + jobsText + "\n"
                        + "⚠️ Improvements:\n"
                        + "• Add certifications\n"
                        + "• Add specific projects\n"
                        + "• Use standard formatting";

        tvResult.setText(finalResult);

        // SAVE FIREBASE HISTORY
        HashMap<String, Object> map = new HashMap<>();
        map.put("result", finalResult);
        firestore.collection("history").add(map);

        // OPEN JOB SCREEN
        JobRepository.jobList = detectedJobs;

        startActivity(
                new Intent(
                        MainActivity.this,
                        JobsActivity.class
                )
        );
    }

    private void addJobIfMatch(String company, String role, String salary, String[] primarySkills, String[] secondarySkills, String source) {
        boolean primaryMatched = false;
        int matchCount = 0;

        // At least one primary skill must match
        for (String skill : primarySkills) {
            if (detectedSkills.contains(skill)) {
                primaryMatched = true;
                matchCount += 2; // Higher weight for primary skills
            }
        }

        if (!primaryMatched) return;

        // Count secondary skills
        for (String skill : secondarySkills) {
            if (detectedSkills.contains(skill)) {
                matchCount += 1;
            }
        }

        int maxPossible = (primarySkills.length * 2) + secondarySkills.length;
        int percentage = (matchCount * 100) / maxPossible;

        // Normalize percentage to a realistic range (70-98%)
        if (percentage < 70) percentage = 70 + (matchCount * 2);
        if (percentage > 98) percentage = 98;

        detectedJobs.add(new JobModel(company, role, salary, percentage + "%", source));
    }
}