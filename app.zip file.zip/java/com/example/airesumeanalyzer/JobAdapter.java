package com.example.airesumeanalyzer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.JobViewHolder> {

    private Context context;
    private ArrayList<JobModel> jobList;

    public JobAdapter(Context context, ArrayList<JobModel> jobList) {
        this.context = context;
        this.jobList = jobList;
    }

    @NonNull
    @Override
    public JobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_job, parent, false);
        return new JobViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JobViewHolder holder, int position) {
        JobModel job = jobList.get(position);

        holder.companyTv.setText(job.getCompany());
        holder.roleTv.setText(job.getRole());
        holder.salaryTv.setText(job.getSalary());
        holder.matchTv.setText(job.getMatch());
        holder.sourceTv.setText(job.getSource());
        holder.locationTv.setText(job.getLocation());
        holder.postedDateTv.setText(job.getPostedDate());

        holder.applyBtn.setOnClickListener(v -> {
            String url;
            String query = job.getRole().replace(" ", "+");
            String company = job.getCompany().replace(" ", "+");

            // requirement: Diverse platform support with direct search restricted links
            switch (job.getSource().toLowerCase()) {
                case "google career":
                    url = "https://www.google.com/about/careers/applications/jobs/results/?q=" + query;
                    break;
                case "linkedin":
                    url = "https://www.linkedin.com/jobs/search/?keywords=" + query + "&location=" + job.getLocation();
                    break;
                case "indeed":
                    url = "https://www.indeed.com/jobs?q=" + query + "+" + company;
                    break;
                case "glassdoor":
                    url = "https://www.glassdoor.com/Job/jobs.htm?sc.keyword=" + query;
                    break;
                case "monster":
                    url = "https://www.monster.com/jobs/search/?q=" + query;
                    break;
                case "openai careers":
                    url = "https://openai.com/careers/search?q=" + query;
                    break;
                case "adobe careers":
                    url = "https://adobe.wd5.myworkdayjobs.com/external_experienced?q=" + query;
                    break;
                case "remote.co":
                    url = "https://remote.co/remote-jobs/search/?search=" + query;
                    break;
                default:
                    url = "https://www.google.com/search?q=" + query + "+" + company + "+jobs";
            }

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return jobList.size();
    }

    public static class JobViewHolder extends RecyclerView.ViewHolder {
        TextView companyTv, roleTv, salaryTv, matchTv, sourceTv, locationTv, postedDateTv;
        Button applyBtn;

        public JobViewHolder(@NonNull View itemView) {
            super(itemView);
            companyTv = itemView.findViewById(R.id.companyTv);
            roleTv = itemView.findViewById(R.id.roleTv);
            salaryTv = itemView.findViewById(R.id.salaryTv);
            matchTv = itemView.findViewById(R.id.matchTv);
            sourceTv = itemView.findViewById(R.id.sourceTv);
            locationTv = itemView.findViewById(R.id.locationTv);
            postedDateTv = itemView.findViewById(R.id.postedDateTv);
            applyBtn = itemView.findViewById(R.id.applyBtn);
        }
    }
}