package com.example.airesumeanalyzer;

public class JobModel {
    private String company;
    private String role;
    private String salary;
    private String match;
    private String source;
    private String location;
    private String postedDate;

    // Full constructor (7 arguments)
    public JobModel(String company, String role, String salary, String match, String source, String location, String postedDate) {
        this.company = company;
        this.role = role;
        this.salary = salary;
        this.match = match;
        this.source = source;
        this.location = location;
        this.postedDate = postedDate;
    }

    // 5-argument constructor for compatibility
    public JobModel(String company, String role, String salary, String match, String source) {
        this(company, role, salary, match, source, "Remote", "Just now");
    }

    // 4-argument constructor for legacy calls
    public JobModel(String company, String role, String salary, String match) {
        this(company, role, salary, match, "LinkedIn", "Remote", "Just now");
    }

    // Default constructor for Firebase
    public JobModel() {}

    public String getCompany() { return company; }
    public String getRole() { return role; }
    public String getSalary() { return salary; }
    public String getMatch() { return match; }
    public String getSource() { return source; }
    public String getLocation() { return location; }
    public String getPostedDate() { return postedDate; }
}