package com.example.airesumeanalyzer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class UploadResumeActivity extends AppCompatActivity {

    Button selectPdfBtn;

    TextView fileNameTv, progressTv;

    ProgressBar progressBar;

    FirebaseStorage storage;

    Uri pdfUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_resume);

        storage = FirebaseStorage.getInstance();

        selectPdfBtn = findViewById(R.id.selectPdfBtn);
        fileNameTv = findViewById(R.id.fileNameTv);
        progressTv = findViewById(R.id.progressTv);
        progressBar = findViewById(R.id.progressBar);

        selectPdfBtn.setOnClickListener(v -> openPdfPicker());
    }

    ActivityResultLauncher<String> pdfPicker =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),

                    result -> {

                        if (result != null) {

                            pdfUri = result;

                            String fileName = result.getLastPathSegment();

                            fileNameTv.setText(fileName);

                            uploadPdf();
                        }
                    });

    private void openPdfPicker() {

        pdfPicker.launch("application/pdf");
    }

    private void uploadPdf() {

        progressBar.setVisibility(ProgressBar.VISIBLE);
        progressTv.setVisibility(TextView.VISIBLE);

        StorageReference reference = storage.getReference()
                .child("resumes/" + System.currentTimeMillis() + ".pdf");

        reference.putFile(pdfUri)

                .addOnProgressListener(snapshot -> {

                    double progress =
                            (100.0 * snapshot.getBytesTransferred())
                                    / snapshot.getTotalByteCount();

                    progressBar.setProgress((int) progress);

                    progressTv.setText((int) progress + "% Uploaded");
                })

                .addOnSuccessListener(taskSnapshot -> {

                    Toast.makeText(this,
                            "Resume Uploaded Successfully",
                            Toast.LENGTH_LONG).show();

                    startActivity(
                            new Intent(
                                    UploadResumeActivity.this,
                                    AnalysisActivity.class
                            )
                    );
                })

                .addOnFailureListener(e -> {

                    Toast.makeText(this,
                            e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
    }
}