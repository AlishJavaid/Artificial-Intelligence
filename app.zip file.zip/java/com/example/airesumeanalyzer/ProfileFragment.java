package com.example.airesumeanalyzer;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        RadioGroup themeGroup = view.findViewById(R.id.themeGroup);
        SharedPreferences prefs = requireContext().getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String currentTheme = prefs.getString("theme", "light");

        // Set current radio button
        if (currentTheme.equals("light")) themeGroup.check(R.id.radioLight);
        else if (currentTheme.equals("dark")) themeGroup.check(R.id.radioDark);
        else if (currentTheme.equals("blue")) themeGroup.check(R.id.radioBlue);
        else if (currentTheme.equals("green")) themeGroup.check(R.id.radioGreen);

        themeGroup.setOnCheckedChangeListener((group, checkedId) -> {
            SharedPreferences.Editor editor = prefs.edit();
            if (checkedId == R.id.radioLight) {
                editor.putString("theme", "light");
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            } else if (checkedId == R.id.radioDark) {
                editor.putString("theme", "dark");
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else if (checkedId == R.id.radioBlue) {
                editor.putString("theme", "blue");
            } else if (checkedId == R.id.radioGreen) {
                editor.putString("theme", "green");
            }
            editor.apply();
            // Restart activity to apply theme
            requireActivity().recreate();
        });

        view.findViewById(R.id.btnLogout).setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        return view;
    }
}