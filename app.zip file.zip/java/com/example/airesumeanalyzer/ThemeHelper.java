package com.example.airesumeanalyzer;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class ThemeHelper {

    public static void applyTheme(Activity activity) {
        SharedPreferences prefs = activity.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String theme = prefs.getString("theme", "light");

        switch (theme) {
            case "dark":
                activity.setTheme(R.style.Theme_AIResumeAnalyzer_Dark);
                break;
            case "blue":
                activity.setTheme(R.style.Theme_AIResumeAnalyzer_Blue);
                break;
            case "green":
                activity.setTheme(R.style.Theme_AIResumeAnalyzer_Green);
                break;
            default:
                activity.setTheme(R.style.Theme_AIResumeAnalyzer);
                break;
        }
    }
}