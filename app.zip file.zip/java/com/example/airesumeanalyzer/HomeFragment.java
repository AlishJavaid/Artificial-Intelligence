package com.example.airesumeanalyzer;

import com.example.airesumeanalyzer.BuildConfig;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.firestore.FirebaseFirestore;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@SuppressLint({"SetTextI18n", "SpellCheckingInspection"})
public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";

    // Replace this placeholder string with your direct key from Groq Console
    private static final String GROQ_API_KEY = "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";

    private Button btnAnalyze, btnAskAi;
    private ImageButton btnShare, btnDownloadPdf;
    private TextView tvFileName, tvScore, tvImprovements, tvAiResponse;
    private TextView tvSkillPts, tvStructPts, tvImpactPts;
    private EditText etAiQuestion;
    private PieChart scoreChart;
    private View layoutResults;
    private ChipGroup chipGroupSkills;

    private FirebaseFirestore firestore;
    private final ArrayList<String> detectedSkills = new ArrayList<>();
    private Uri currentFileUri = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        SwipeRefreshLayout swipeRefreshHome = view.findViewById(R.id.swipeRefreshHome);
        Button btnPickFile = view.findViewById(R.id.btnPickFile);
        Button btnGoToJobs = view.findViewById(R.id.btnGoToJobs);

        btnAnalyze = view.findViewById(R.id.btnAnalyze);
        btnShare = view.findViewById(R.id.btnShare);
        btnDownloadPdf = view.findViewById(R.id.btnDownloadPdf);
        tvFileName = view.findViewById(R.id.tvFileName);

        tvScore = view.findViewById(R.id.tvScoreDisplay);
        tvImprovements = view.findViewById(R.id.tvImprovements);
        tvSkillPts = view.findViewById(R.id.tvSkillPts);
        tvStructPts = view.findViewById(R.id.tvStructPts);
        tvImpactPts = view.findViewById(R.id.tvImpactPts);
        scoreChart = view.findViewById(R.id.scoreChart);
        layoutResults = view.findViewById(R.id.layoutResults);
        chipGroupSkills = view.findViewById(R.id.chipGroupSkills);

        etAiQuestion = view.findViewById(R.id.etAiQuestion);
        btnAskAi = view.findViewById(R.id.btnAskAi);
        tvAiResponse = view.findViewById(R.id.tvAiResponse);

        firestore = FirebaseFirestore.getInstance();

        setupChart();

        btnPickFile.setOnClickListener(v -> openFilePicker());
        btnAnalyze.setOnClickListener(v -> analyzeResumeWithGroq());

        btnGoToJobs.setOnClickListener(v -> {
            if (getActivity() instanceof DashboardActivity) {
                ((DashboardActivity) getActivity()).bottomNav.setSelectedItemId(R.id.nav_jobs);
            }
        });

        if (btnShare != null) btnShare.setOnClickListener(v -> shareAnalysisReport());
        if (btnDownloadPdf != null) btnDownloadPdf.setOnClickListener(v -> generatePdfReport());

        if (btnAskAi != null) {
            btnAskAi.setOnClickListener(v -> {
                String question = etAiQuestion.getText().toString().trim();
                if (!question.isEmpty()) {
                    askCustomQuestionToGroq(question);
                } else {
                    Toast.makeText(getContext(), "Please type a question first", Toast.LENGTH_SHORT).show();
                }
            });
        }

        swipeRefreshHome.setOnRefreshListener(() -> {
            if (currentFileUri != null) {
                analyzeResumeWithGroq();
            } else {
                Toast.makeText(getContext(), "Upload a resume first", Toast.LENGTH_SHORT).show();
            }
            swipeRefreshHome.setRefreshing(false);
        });

        if (tvScore != null) {
            tvScore.setOnLongClickListener(v -> {
                copyReportToClipboard();
                return true;
            });
        }

        return view;
    }

    private void setupChart() {
        if (scoreChart == null) return;
        scoreChart.setUsePercentValues(true);
        scoreChart.getDescription().setEnabled(false);
        scoreChart.setDrawHoleEnabled(true);
        scoreChart.setHoleColor(Color.TRANSPARENT);
        scoreChart.setTransparentCircleRadius(0f);
        scoreChart.setEntryLabelColor(Color.TRANSPARENT);
        scoreChart.getLegend().setEnabled(false);
        scoreChart.setTouchEnabled(false);
    }

    private void updateChart(int score) {
        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(score, "Match"));
        entries.add(new PieEntry(100 - score, "Gap"));

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(Color.parseColor("#10B981"), Color.parseColor("#E5E7EB"));
        dataSet.setDrawValues(false);

        PieData data = new PieData(dataSet);
        scoreChart.setData(data);
        scoreChart.invalidate();
        scoreChart.animateY(1400);
    }

    private void copyReportToClipboard() {
        if (tvImprovements.getText().toString().isEmpty()) return;
        String report = "📊 ATS Resume Analysis Report\n" +
                "Score: " + tvScore.getText() + "/100\n" +
                "Skills Identified: " + detectedSkills + "\n" +
                "Recommendations:\n" + tvImprovements.getText();

        ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Resume Report", report);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(getContext(), "Analysis report copied to clipboard!", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareAnalysisReport() {
        if (currentFileUri == null) return;

        String report = "📊 *My Groq Resume Analysis Report*\n\n" +
                "ATS Match Score: " + tvScore.getText() + "/100\n" +
                "Key Skills Found: " + detectedSkills + "\n\n" +
                "🚀 *Improvement Plan:*\n" + tvImprovements.getText() + "\n" +
                "With AI Resume Analyzer App!";

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(intent, "Share Analysis via"));
    }

    private void generatePdfReport() {
        try {
            String fileName = "Resume_Analysis_" + System.currentTimeMillis() + ".pdf";
            File pdfFile = new File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName);
            PdfWriter writer = new PdfWriter(new FileOutputStream(pdfFile));
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            document.add(new Paragraph("AI Resume Analysis Report").setBold().setFontSize(20).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("\nATS Score: " + tvScore.getText() + "/100").setBold().setFontSize(16));
            document.add(new Paragraph("\nScore Breakdown:").setBold());
            document.add(new Paragraph("• Skills: " + tvSkillPts.getText()));
            document.add(new Paragraph("• Structure: " + tvStructPts.getText()));
            document.add(new Paragraph("• Impact: " + tvImpactPts.getText()));
            document.add(new Paragraph("\nDetected Strengths:").setBold());
            document.add(new Paragraph(detectedSkills.toString()));
            document.add(new Paragraph("\nExpert Improvement Roadmap:").setBold());
            document.add(new Paragraph(tvImprovements.getText().toString()));
            document.add(new Paragraph("\nGenerated by AI Resume Analyzer").setItalic().setFontSize(10).setTextAlignment(TextAlignment.CENTER));

            document.close();

            Uri uri = FileProvider.getUriForFile(requireContext(), requireContext().getPackageName() + ".fileprovider", pdfFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);

            Toast.makeText(getContext(), "PDF generated and saved in Documents", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getContext(), "PDF Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private final ActivityResultLauncher<String[]> filePicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) {
                    currentFileUri = uri;
                    tvFileName.setText("File: " + uri.getLastPathSegment());
                    if (btnAnalyze != null) btnAnalyze.setEnabled(true);

                    detectedSkills.clear();
                    JobRepository.jobList.clear();
                    if (layoutResults != null) layoutResults.setVisibility(View.GONE);
                    if (btnShare != null) btnShare.setVisibility(View.GONE);
                    if (btnDownloadPdf != null) btnDownloadPdf.setVisibility(View.GONE);
                }
            });

    private void openFilePicker() {
        filePicker.launch(new String[]{"image/*", "application/pdf"});
    }

    private String encodeFileToBase64(Uri uri) {
        try {
            String mimeType = requireContext().getContentResolver().getType(uri);
            if ("application/pdf".equals(mimeType)) {
                return encodePdfPageToBase64(uri);
            }

            InputStream inputStream = requireContext().getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;
            ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                byteBuffer.write(buffer, 0, len);
            }
            inputStream.close();
            return android.util.Base64.encodeToString(byteBuffer.toByteArray(), android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e(TAG, "Encoding Error", e);
            return null;
        }
    }

    private String encodePdfPageToBase64(Uri uri) {
        try {
            ParcelFileDescriptor fd = requireContext().getContentResolver().openFileDescriptor(uri, "r");
            if (fd == null) return null;
            PdfRenderer renderer = new PdfRenderer(fd);
            if (renderer.getPageCount() == 0) {
                renderer.close();
                fd.close();
                return null;
            }
            PdfRenderer.Page page = renderer.openPage(0);
            Bitmap bitmap = Bitmap.createBitmap(page.getWidth(), page.getHeight(), Bitmap.Config.ARGB_8888);
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            page.close();
            renderer.close();
            fd.close();

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos);
            return android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e(TAG, "PDF Rendering Error", e);
            return null;
        }
    }

    private void analyzeResumeWithGroq() {
        if (currentFileUri == null) {
            Toast.makeText(getContext(), "Please choose a document first.", Toast.LENGTH_SHORT).show();
            return;
        }

        if ("YOUR_GROQ_API_KEY_HERE".equals(GROQ_API_KEY) || GROQ_API_KEY.isEmpty()) {
            Toast.makeText(getContext(), "API Key is missing. Please update GROQ_API_KEY variable in HomeFragment.", Toast.LENGTH_LONG).show();
            return;
        }

        btnAnalyze.setEnabled(false);
        Toast.makeText(getContext(), "Groq AI is processing...", Toast.LENGTH_LONG).show();

        String base64Data = encodeFileToBase64(currentFileUri);
        if (base64Data == null) {
            Toast.makeText(getContext(), "Failed to process file.", Toast.LENGTH_SHORT).show();
            btnAnalyze.setEnabled(true);
            return;
        }

        String base64Prefix = "data:image/jpeg;base64," + base64Data;

        try {
            JSONObject payload = new JSONObject();
            // Using Groq's active multimodal vision model
            payload.put("model", "meta-llama/llama-4-scout-17b-16e-instruct");

            JSONArray messages = new JSONArray();
            JSONObject messageObj = new JSONObject();
            messageObj.put("role", "user");

            JSONArray contentArray = new JSONArray();
            contentArray.put(new JSONObject().put("type", "text").put("text", "Act as an expert ATS. Analyze this resume. Return ONLY a JSON object with keys: totalScore, skillScore, structureScore, impactScore, skills (array), improvements (string)."));
            contentArray.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", base64Prefix)));

            messageObj.put("content", contentArray);
            messages.put(messageObj);
            payload.put("messages", messages);
            payload.put("response_format", new JSONObject().put("type", "json_object"));

            OkHttpClient client = new OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build();
            RequestBody body = RequestBody.create(payload.toString(), MediaType.parse("application/json"));

            Request request = new Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer " + GROQ_API_KEY)
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(@NonNull Call call, @NonNull java.io.IOException e) {
                    Log.e(TAG, "API Call Failed", e);
                    safeUpdateUi(() -> { Toast.makeText(getContext(), "Network Error: " + e.getMessage(), Toast.LENGTH_SHORT).show(); btnAnalyze.setEnabled(true); });
                }

                @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws java.io.IOException {
                    String res = response.body() != null ? response.body().string() : "";
                    Log.d(TAG, "Response: " + res);

                    try {
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.has("error")) {
                            JSONObject errorObj = jsonObject.getJSONObject("error");
                            String errorMsg = errorObj.optString("message", "Unknown Groq Error");
                            throw new JSONException(errorMsg);
                        }

                        if (!jsonObject.has("choices")) {
                            throw new JSONException("No 'choices' in response. Check API balance or limits.");
                        }

                        String content = jsonObject.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
                        JSONObject parsed = new JSONObject(content);

                        final int totalScore = parsed.optInt("totalScore", 0);
                        final int skillScore = parsed.optInt("skillScore", 0);
                        final int structureScore = parsed.optInt("structureScore", 0);
                        final int impactScore = parsed.optInt("impactScore", 0);
                        final String improvements = parsed.optString("improvements", "No specific feedback.");

                        JSONArray skillsArray = parsed.optJSONArray("skills");
                        final ArrayList<String> freshSkills = new ArrayList<>();
                        if (skillsArray != null) {
                            for (int i = 0; i < skillsArray.length(); i++) freshSkills.add(skillsArray.getString(i));
                        }

                        safeUpdateUi(() -> {
                            detectedSkills.clear();
                            detectedSkills.addAll(freshSkills);
                            if (tvScore != null) tvScore.setText(String.valueOf(totalScore));
                            if (tvSkillPts != null) tvSkillPts.setText(String.valueOf(skillScore));
                            if (tvStructPts != null) tvStructPts.setText(String.valueOf(structureScore));
                            if (tvImpactPts != null) tvImpactPts.setText(String.valueOf(impactScore));
                            if (tvImprovements != null) tvImprovements.setText(improvements);
                            if (chipGroupSkills != null) {
                                chipGroupSkills.removeAllViews();
                                for (String s : detectedSkills) addSkillChip(s);
                            }
                            updateChart(totalScore);
                            fetchDiversifiedJobRecommendations();
                            if (layoutResults != null) layoutResults.setVisibility(View.VISIBLE);
                            if (btnShare != null) btnShare.setVisibility(View.VISIBLE);
                            if (btnDownloadPdf != null) btnDownloadPdf.setVisibility(View.VISIBLE);
                            btnAnalyze.setEnabled(true);

                            HashMap<String, Object> map = new HashMap<>();
                            map.put("score", totalScore);
                            map.put("skills", detectedSkills);
                            map.put("timestamp", System.currentTimeMillis());
                            firestore.collection("analysis_history").add(map);
                            Toast.makeText(getContext(), "Analysis Complete", Toast.LENGTH_SHORT).show();
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "Parsing Error", e);
                        safeUpdateUi(() -> {
                            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            btnAnalyze.setEnabled(true);
                        });
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Unexpected Error", e);
            btnAnalyze.setEnabled(true);
        }
    }

    private void askCustomQuestionToGroq(String question) {
        if (currentFileUri == null) {
            Toast.makeText(getContext(), "Upload a resume first.", Toast.LENGTH_SHORT).show();
            return;
        }

        if ("YOUR_GROQ_API_KEY_HERE".equals(GROQ_API_KEY) || GROQ_API_KEY.isEmpty()) {
            Toast.makeText(getContext(), "API Key is missing.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (tvAiResponse != null) {
            tvAiResponse.setVisibility(View.VISIBLE);
            tvAiResponse.setText("Groq AI is analyzing... 🤖");
        }
        btnAskAi.setEnabled(false);

        String base64Data = encodeFileToBase64(currentFileUri);
        if (base64Data == null) {
            btnAskAi.setEnabled(true);
            return;
        }

        String base64Prefix = "data:image/jpeg;base64," + base64Data;

        try {
            JSONObject payload = new JSONObject();
            payload.put("model", "meta-llama/llama-4-scout-17b-16e-instruct");

            JSONArray messages = new JSONArray();
            JSONObject messageObj = new JSONObject();
            messageObj.put("role", "user");

            JSONArray contentArray = new JSONArray();
            contentArray.put(new JSONObject().put("type", "text").put("text", "Answer this: " + question));
            contentArray.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", base64Prefix)));

            messageObj.put("content", contentArray);
            messages.put(messageObj);
            payload.put("messages", messages);

            RequestBody body = RequestBody.create(payload.toString(), MediaType.parse("application/json"));
            Request request = new Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer " + GROQ_API_KEY)
                    .post(body)
                    .build();

            new OkHttpClient().newCall(request).enqueue(new Callback() {
                @Override public void onFailure(@NonNull Call call, @NonNull java.io.IOException e) {
                    safeUpdateUi(() -> { if (tvAiResponse != null) tvAiResponse.setText("Error: " + e.getMessage()); btnAskAi.setEnabled(true); });
                }

                @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws java.io.IOException {
                    String res = response.body() != null ? response.body().string() : "";
                    try {
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.has("error")) {
                            throw new JSONException(jsonObject.getJSONObject("error").getString("message"));
                        }
                        final String answer = jsonObject.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
                        safeUpdateUi(() -> {
                            if (tvAiResponse != null) tvAiResponse.setText(answer);
                            btnAskAi.setEnabled(true);
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "AI Question Parse Error", e);
                        safeUpdateUi(() -> { if (tvAiResponse != null) tvAiResponse.setText("Parse Error: " + e.getMessage()); btnAskAi.setEnabled(true); });
                    }
                }
            });
        } catch (Exception e) { btnAskAi.setEnabled(true); }
    }

    private void addSkillChip(String skill) {
        if (getContext() == null || chipGroupSkills == null) return;
        Chip chip = new Chip(getContext());
        chip.setText(skill.substring(0, 1).toUpperCase() + skill.substring(1));
        chip.setChipBackgroundColorResource(android.R.color.darker_gray);
        chipGroupSkills.addView(chip);
    }

    private void safeUpdateUi(Runnable runnable) {
        if (getActivity() != null && isAdded()) {
            getActivity().runOnUiThread(runnable);
        }
    }

    private void fetchDiversifiedJobRecommendations() {
        List<JobModel> allPossibleJobs = new ArrayList<>();

        allPossibleJobs.add(new JobModel("Google", "Android Core Engineer", "Competitive", "98%", "Google Career", "Mountain View, CA", "2h ago"));
        allPossibleJobs.add(new JobModel("Zomato", "Product Engineer (Android)", "25-35 LPA", "92%", "LinkedIn", "Remote", "Today"));
        allPossibleJobs.add(new JobModel("Uber", "Senior Mobile Lead", "Competitive", "88%", "Glassdoor", "Hyderabad", "1d ago"));
        allPossibleJobs.add(new JobModel("OpenAI", "NLP Research Scientist", "$210k - $290k", "96%", "OpenAI Careers", "San Francisco", "Just now"));
        allPossibleJobs.add(new JobModel("Tesla", "Data Ops Specialist", "Competitive", "91%", "Indeed", "Austin, TX", "4h ago"));
        allPossibleJobs.add(new JobModel("Meta", "React Frontend Architect", "Competitive", "94%", "LinkedIn", "London, UK", "3h ago"));
        allPossibleJobs.add(new JobModel("Vercel", "Full Stack Engineer", "$140k", "85%", "Remote.co", "Worldwide", "2d ago"));
        allPossibleJobs.add(new JobModel("Amazon", "SDE-II (AWS Cloud)", "Competitive", "96%", "Amazon Jobs", "Seattle, WA", "3h ago"));
        allPossibleJobs.add(new JobModel("Microsoft", "Azure Backend Developer", "30-45 LPA", "90%", "SimplyHired", "Hyderabad, IN", "Today"));
        allPossibleJobs.add(new JobModel("Adobe", "Product Designer II", "Competitive", "93%", "Indeed", "San Jose, CA", "1h ago"));
        allPossibleJobs.add(new JobModel("Canva", "Visual Designer", "Competitive", "88%", "LinkedIn", "Sydney, AU", "1d ago"));
        allPossibleJobs.add(new JobModel("NIBGE", "Bioinformatics Researcher", "Competitive", "95%", "LinkedIn", "Faisalabad, PK", "Just now"));
        allPossibleJobs.add(new JobModel("Bayer Crop Science", "Plant Genetics Analyst", "Market Rate", "92%", "Indeed", "Remote", "2h ago"));
        allPossibleJobs.add(new JobModel("Syngenta", "CRISPR Research Associate", "Competitive", "89%", "Glassdoor", "Global", "1d ago"));
        allPossibleJobs.add(new JobModel("CGIAR", "Agricultural Data Scientist (R/QGIS)", "Competitive", "94%", "LinkedIn", "Remote", "3h ago"));

        List<JobModel> filteredJobs = new ArrayList<>();

        for (JobModel job : allPossibleJobs) {
            String role = job.getRole().toLowerCase();
            String company = job.getCompany().toLowerCase();

            boolean skillFound = false;
            for (String skill : detectedSkills) {
                String lowerSkill = skill.toLowerCase();
                if (role.contains(lowerSkill) || company.contains(lowerSkill) ||
                        (lowerSkill.equals("r") && role.contains("data scientist")) ||
                        (lowerSkill.equals("qgis") && role.contains("agricultural"))) {
                    skillFound = true;
                    break;
                }
            }

            if (skillFound) {
                filteredJobs.add(job);
            }
        }

        if (filteredJobs.isEmpty()) {
            filteredJobs.add(new JobModel("Accenture", "Technology Consultant", "Market Rate", "75%", "LinkedIn", "Global", "Active"));
            filteredJobs.add(new JobModel("Cognizant", "Business Analyst", "Competitive", "72%", "Glassdoor", "Remote", "2d ago"));
            filteredJobs.add(new JobModel("Wipro", "Project Coordinator", "6 LPA", "68%", "Glassdoor", "Bangalore", "3d ago"));
        }

        Collections.shuffle(filteredJobs);
        JobRepository.jobList.clear();
        JobRepository.jobList.addAll(filteredJobs);
    }
}