package com.example.airesumeanalyzer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class SkillEngine {

    // Large skill database (expandable)
    private static final List<String> SKILL_POOL = Arrays.asList(

            // Programming
            "java", "python", "kotlin", "c++", "c#", "javascript", "typescript",

            // Android
            "android", "firebase", "xml", "jetpack", "mvvm",

            // Web
            "html", "css", "react", "angular", "node", "express",

            // Data
            "sql", "mysql", "mongodb", "oracle",

            // Tools
            "git", "github", "postman", "figma", "photoshop",

            // AI/ML
            "machine learning", "deep learning", "ai", "data science",

            // Business
            "marketing", "seo", "management",

            // Soft skills
            "communication", "leadership", "teamwork"
    );

    private static final List<String> STOP_WORDS = Arrays.asList(

            "and", "the", "is", "in", "at", "to", "a", "of",
            "i", "we", "you", "he", "she", "they", "it",
            "with", "for", "on", "as", "by"
    );

    public static String extractSkills(String text) {

        text = text.toLowerCase();

        HashMap<String, Integer> skillCount = new HashMap<>();

        // check full skill pool
        for (String skill : SKILL_POOL) {

            if (text.contains(skill)) {

                skillCount.put(skill,
                        skillCount.getOrDefault(skill, 0) + 1);
            }
        }

        StringBuilder result = new StringBuilder();

        for (String skill : skillCount.keySet()) {

            result.append("• ")
                    .append(capitalize(skill))
                    .append("\n");
        }

        if (result.length() == 0) {

            return "• Communication\n• Problem Solving\n• Learning Ability";
        }

        return result.toString();
    }

    public static String detectJob(String text) {

        text = text.toLowerCase();

        if (text.contains("android") || text.contains("java")) {

            return "• Android Developer\n• Java Developer\n• Mobile App Developer";
        }

        if (text.contains("python") || text.contains("machine learning")) {

            return "• Data Scientist\n• AI Engineer\n• Python Developer";
        }

        if (text.contains("html") || text.contains("css")) {

            return "• Web Developer\n• Frontend Developer";
        }

        if (text.contains("marketing")) {

            return "• Digital Marketer\n• SEO Specialist";
        }

        return "• General Software Developer\n• IT Support Engineer";
    }

    private static String capitalize(String str) {

        return str.substring(0, 1).toUpperCase()
                + str.substring(1);
    }
}