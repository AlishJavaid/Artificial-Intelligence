package com.example.airesumeanalyzer;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class ProfileActivity
        extends AppCompatActivity {

    Switch darkModeSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        darkModeSwitch =
                findViewById(R.id.darkModeSwitch);

        SharedPreferences preferences =
                getSharedPreferences(
                        "settings",
                        MODE_PRIVATE
                );

        boolean isDark =
                preferences.getBoolean(
                        "dark_mode",
                        false
                );

        darkModeSwitch.setChecked(isDark);

        if (isDark) {

            AppCompatDelegate.setDefaultNightMode(
                    AppCompatDelegate.MODE_NIGHT_YES
            );
        }

        darkModeSwitch.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    SharedPreferences.Editor editor =
                            preferences.edit();

                    editor.putBoolean(
                            "dark_mode",
                            isChecked
                    );

                    editor.apply();

                    if (isChecked) {

                        AppCompatDelegate
                                .setDefaultNightMode(
                                        AppCompatDelegate.MODE_NIGHT_YES
                                );

                    } else {

                        AppCompatDelegate
                                .setDefaultNightMode(
                                        AppCompatDelegate.MODE_NIGHT_NO
                                );
                    }
                });
    }
}