package com.example.airesumeanalyzer;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class HistoryActivity
        extends AppCompatActivity {

    RecyclerView recyclerView;

    ArrayList<HistoryModel> list;

    HistoryAdapter adapter;

    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        recyclerView =
                findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        list = new ArrayList<>();

        adapter = new HistoryAdapter(list);

        recyclerView.setAdapter(adapter);

        firestore = FirebaseFirestore.getInstance();

        firestore.collection("history")

                .get()

                .addOnSuccessListener(queryDocumentSnapshots -> {

                    list.clear();

                    queryDocumentSnapshots.forEach(document -> {

                        HistoryModel model =
                                document.toObject(
                                        HistoryModel.class
                                );

                        list.add(model);
                    });

                    adapter.notifyDataSetChanged();
                });
    }
}