package com.example.airesumeanalyzer;

public class HistoryModel {

    String result;

    public HistoryModel() {
    }

    public HistoryModel(String result) {

        this.result = result;
    }

    public String getResult() {

        return result;
    }
}