package com.example.airesumeanalyzer;

import java.util.HashMap;

public class SkillDatabase {

    public static HashMap<String, String[]> getSkillMap() {

        HashMap<String, String[]> map = new HashMap<>();

        // SOFTWARE DEVELOPMENT
        map.put("Android Developer", new String[]{
                "java","kotlin","android","firebase","xml","jetpack",
                "room","sqlite","retrofit","mvvm","api","material design"
        });

        map.put("Java Developer", new String[]{
                "java","spring","hibernate","jdbc","jpa","maven",
                "gradle","rest api","microservices","sql"
        });

        map.put("Web Developer", new String[]{
                "html","css","javascript","bootstrap","react",
                "nodejs","php","laravel","wordpress","jquery"
        });

        map.put("Frontend Developer", new String[]{
                "react","angular","vue","html","css","javascript",
                "typescript","responsive design","bootstrap"
        });

        map.put("Backend Developer", new String[]{
                "nodejs","express","spring","django","flask",
                "api","database","mongodb","mysql","postgresql"
        });

        map.put("Full Stack Developer", new String[]{
                "react","nodejs","mongodb","mysql","html",
                "css","javascript","api","express","git"
        });

        map.put("Python Developer", new String[]{
                "python","django","flask","pandas","numpy",
                "automation","api","scripting","sql"
        });

        map.put("Data Scientist", new String[]{
                "python","machine learning","data science",
                "tensorflow","pandas","numpy","statistics",
                "data analysis","power bi","sql"
        });

        map.put("AI Engineer", new String[]{
                "artificial intelligence","machine learning",
                "deep learning","tensorflow","pytorch",
                "nlp","computer vision","llm","transformers"
        });

        map.put("Cyber Security Analyst", new String[]{
                "cybersecurity","network security","penetration testing",
                "ethical hacking","siem","vulnerability assessment",
                "incident response","firewall"
        });

        // DESIGN
        map.put("Graphic Designer", new String[]{
                "photoshop","illustrator","figma",
                "branding","logo design","poster design",
                "ui","graphic design"
        });

        map.put("UI UX Designer", new String[]{
                "figma","wireframe","prototype",
                "user research","ui","ux",
                "adobe xd","design thinking"
        });

        // BUSINESS
        map.put("Digital Marketing Specialist", new String[]{
                "seo","social media","marketing",
                "google ads","facebook ads","content marketing",
                "analytics","email marketing"
        });

        map.put("Sales Executive", new String[]{
                "sales","lead generation","crm",
                "customer acquisition","negotiation",
                "business development"
        });

        map.put("Business Analyst", new String[]{
                "business analysis","requirements gathering",
                "uml","agile","jira","process improvement",
                "stakeholder management"
        });

        // FINANCE
        map.put("Accountant", new String[]{
                "accounting","bookkeeping","quickbooks",
                "taxation","audit","financial reporting",
                "excel","balance sheet"
        });

        map.put("Financial Analyst", new String[]{
                "finance","forecasting","financial modeling",
                "budgeting","excel","investment analysis"
        });

        // EDUCATION
        map.put("Teacher", new String[]{
                "teaching","education","lesson planning",
                "curriculum","students","classroom management"
        });

        map.put("Lecturer", new String[]{
                "research","teaching","academic",
                "university","curriculum development"
        });

        // HEALTHCARE
        map.put("Doctor", new String[]{
                "medical","diagnosis","patient care",
                "clinical","surgery","hospital",
                "medicine","treatment"
        });

        map.put("Nurse", new String[]{
                "nursing","patient care","healthcare",
                "clinical","hospital","medication",
                "medical records"
        });

        map.put("Pharmacist", new String[]{
                "pharmacy","medication","drug dispensing",
                "patient counseling","inventory management"
        });

        // ENGINEERING
        map.put("Civil Engineer", new String[]{
                "civil engineering","autocad","construction",
                "site supervision","surveying","structural design"
        });

        map.put("Mechanical Engineer", new String[]{
                "mechanical engineering","cad","solidworks",
                "manufacturing","maintenance","thermodynamics"
        });

        map.put("Electrical Engineer", new String[]{
                "electrical engineering","power systems",
                "circuit design","electronics","plc","automation"
        });

        // HR
        map.put("HR Specialist", new String[]{
                "recruitment","talent acquisition",
                "employee relations","hr","onboarding",
                "performance management"
        });

        // LEGAL
        map.put("Lawyer", new String[]{
                "law","legal research","litigation",
                "contracts","compliance","court"
        });

        // MEDIA
        map.put("Content Writer", new String[]{
                "content writing","blog writing","copywriting",
                "seo writing","editing","proofreading"
        });

        map.put("Journalist", new String[]{
                "journalism","reporting","news writing",
                "interviewing","media"
        });

        // MANAGEMENT
        map.put("Project Manager", new String[]{
                "project management","agile","scrum",
                "jira","stakeholder management",
                "risk management"
        });

        map.put("Operations Manager", new String[]{
                "operations","supply chain",
                "inventory management","logistics",
                "process improvement"
        });

        // CUSTOMER SERVICE
        map.put("Customer Support Representative", new String[]{
                "customer service","call center",
                "customer support","crm",
                "problem resolution"
        });

        // ADD MORE PROFESSIONS HERE...

        return map;
    }
}