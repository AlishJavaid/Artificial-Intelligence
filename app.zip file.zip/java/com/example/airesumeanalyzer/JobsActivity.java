package com.example.airesumeanalyzer;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class JobsActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    JobAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobs);

        recyclerView =
                findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        adapter = new JobAdapter(
                this,
                JobRepository.jobList
        );

        recyclerView.setAdapter(adapter);
    }
}