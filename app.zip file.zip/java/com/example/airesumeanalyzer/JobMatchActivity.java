package com.example.airesumeanalyzer;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class JobMatchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_match);
    }
}