package com.example.airesumeanalyzer;

import java.util.ArrayList;

public class JobRepository {

    public static ArrayList<JobModel> jobList = new ArrayList<>();
    
    // Cache for real-time refresh logic
    public static String lastExtractedText = "";
    public static ArrayList<String> lastDetectedSkills = new ArrayList<>();
}