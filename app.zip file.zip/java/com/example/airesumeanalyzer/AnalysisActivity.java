package com.example.airesumeanalyzer;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AnalysisActivity extends AppCompatActivity {

    TextView resultTv;
    Button analyzeAiBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);

        resultTv = findViewById(R.id.resultTv);
        analyzeAiBtn = findViewById(R.id.analyzeAiBtn);

        analyzeAiBtn.setOnClickListener(v -> analyzeResume());
    }

    private void analyzeResume() {

        String result =
                "ATS Resume Score: 85/100\n\n" +

                        "Skills Detected:\n" +
                        "• Java\n" +
                        "• Android Development\n" +
                        "• Firebase\n" +
                        "• XML UI Design\n\n" +

                        "Resume Improvements:\n" +
                        "• Add more projects\n" +
                        "• Add internship experience\n" +
                        "• Improve resume summary\n" +
                        "• Add GitHub profile\n\n" +

                        "Suitable Jobs:\n" +
                        "• Android Developer\n" +
                        "• Java Developer\n" +
                        "• Mobile App Developer\n" +
                        "• Firebase Developer\n\n" +

                        "Final Suggestion:\n" +
                        "Your resume looks good for entry-level Android jobs.";

        resultTv.setText(result);
    }
}